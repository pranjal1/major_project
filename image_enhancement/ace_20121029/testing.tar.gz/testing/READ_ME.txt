Each folder has 4 images:
	*) 3 images are labelled as:
		ace_**** -> image enhanced using Automatic Color Enhancement
		hist_*** -> histogram equalized image
		another one is original image in low light
		
 	*) last one is result labelled as result.

